Participantes:
 - Aisha Gandarova
 - Juantan Pan
 - Emilio Salvador Fuster